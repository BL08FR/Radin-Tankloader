LiquidCrystal hd44780 examples
==============================

The LiquidCrystal library comes bundled with the IDE.
It controls the LCD using Arduino pins directly connected to the LCD.
